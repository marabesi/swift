//
//  Pokemons.swift
//  FiapApp
//
//  Created by Matheus Marabesi on 8/14/16.
//  Copyright © 2016 Matheus Marabesi. All rights reserved.
//

import UIKit

class Pokemons: NSObject {

    var index: Int = 0
    var name: String = ""
    var image: UIImage!
    
}
